create definer = c8payroll@localhost event ACCRUED
  on schedule
    every '25' DAY
      starts '2018-01-06 00:00:00'
  on completion preserve
  enable
do
  UPDATE c8elearn.staff SET leaveAccrued = leaveAccrued + leaveDaysEntitled/12, leaveBalanceDays = leaveBalanceDays + leaveDaysEntitled/12;

